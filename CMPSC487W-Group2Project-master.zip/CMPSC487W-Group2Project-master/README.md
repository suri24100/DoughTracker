# CMPSC487W-Group2Project

This is a sample README markdown file for our group git repository.